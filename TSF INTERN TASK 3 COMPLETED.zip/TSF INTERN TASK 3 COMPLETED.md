# Name- Rahul Mohaniya
 

# DATA ANALYSIS ON A US RETAIL FIRM 
# TSF INTERN TASK 3
 

importing the libraries


```python
import math
import warnings
import numpy as np 
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import seaborn as sns
import matplotlib.pyplot as plt
warnings.filterwarnings('ignore')
```

#LOADING THE DATA


```python
df = pd.read_csv('E:\Global Terrorism - START data\SampleSuperstore.csv')
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Ship Mode</th>
      <th>Segment</th>
      <th>Country</th>
      <th>City</th>
      <th>State</th>
      <th>Postal Code</th>
      <th>Region</th>
      <th>Category</th>
      <th>Sub-Category</th>
      <th>Sales</th>
      <th>Quantity</th>
      <th>Discount</th>
      <th>Profit</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Second Class</td>
      <td>Consumer</td>
      <td>United States</td>
      <td>Henderson</td>
      <td>Kentucky</td>
      <td>42420</td>
      <td>South</td>
      <td>Furniture</td>
      <td>Bookcases</td>
      <td>261.9600</td>
      <td>2</td>
      <td>0.00</td>
      <td>41.9136</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Second Class</td>
      <td>Consumer</td>
      <td>United States</td>
      <td>Henderson</td>
      <td>Kentucky</td>
      <td>42420</td>
      <td>South</td>
      <td>Furniture</td>
      <td>Chairs</td>
      <td>731.9400</td>
      <td>3</td>
      <td>0.00</td>
      <td>219.5820</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Second Class</td>
      <td>Corporate</td>
      <td>United States</td>
      <td>Los Angeles</td>
      <td>California</td>
      <td>90036</td>
      <td>West</td>
      <td>Office Supplies</td>
      <td>Labels</td>
      <td>14.6200</td>
      <td>2</td>
      <td>0.00</td>
      <td>6.8714</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Standard Class</td>
      <td>Consumer</td>
      <td>United States</td>
      <td>Fort Lauderdale</td>
      <td>Florida</td>
      <td>33311</td>
      <td>South</td>
      <td>Furniture</td>
      <td>Tables</td>
      <td>957.5775</td>
      <td>5</td>
      <td>0.45</td>
      <td>-383.0310</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Standard Class</td>
      <td>Consumer</td>
      <td>United States</td>
      <td>Fort Lauderdale</td>
      <td>Florida</td>
      <td>33311</td>
      <td>South</td>
      <td>Office Supplies</td>
      <td>Storage</td>
      <td>22.3680</td>
      <td>2</td>
      <td>0.20</td>
      <td>2.5164</td>
    </tr>
  </tbody>
</table>
</div>




```python
print(df.shape)
print(df.columns.tolist())
```

    (9994, 13)
    ['Ship Mode', 'Segment', 'Country', 'City', 'State', 'Postal Code', 'Region', 'Category', 'Sub-Category', 'Sales', 'Quantity', 'Discount', 'Profit']
    

# DATA PREPROCESSING
Let's Check if dataset contain null values


```python
df.isnull().sum()
```




    Ship Mode       0
    Segment         0
    Country         0
    City            0
    State           0
    Postal Code     0
    Region          0
    Category        0
    Sub-Category    0
    Sales           0
    Quantity        0
    Discount        0
    Profit          0
    dtype: int64



let's check if data contain any duplicate values


```python
df.duplicated().sum()
```




    17



Deleting duplicate data 


```python
df.drop_duplicates(keep='first', inplace=True)
df.shape
```




    (9977, 13)




```python
for column in df.columns.tolist():
    if len(df[column].unique())< 50:
        print(column,' : ' ,df[column].unique().tolist())
```

    Ship Mode  :  ['Second Class', 'Standard Class', 'First Class', 'Same Day']
    Segment  :  ['Consumer', 'Corporate', 'Home Office']
    Country  :  ['United States']
    State  :  ['Kentucky', 'California', 'Florida', 'North Carolina', 'Washington', 'Texas', 'Wisconsin', 'Utah', 'Nebraska', 'Pennsylvania', 'Illinois', 'Minnesota', 'Michigan', 'Delaware', 'Indiana', 'New York', 'Arizona', 'Virginia', 'Tennessee', 'Alabama', 'South Carolina', 'Oregon', 'Colorado', 'Iowa', 'Ohio', 'Missouri', 'Oklahoma', 'New Mexico', 'Louisiana', 'Connecticut', 'New Jersey', 'Massachusetts', 'Georgia', 'Nevada', 'Rhode Island', 'Mississippi', 'Arkansas', 'Montana', 'New Hampshire', 'Maryland', 'District of Columbia', 'Kansas', 'Vermont', 'Maine', 'South Dakota', 'Idaho', 'North Dakota', 'Wyoming', 'West Virginia']
    Region  :  ['South', 'West', 'Central', 'East']
    Category  :  ['Furniture', 'Office Supplies', 'Technology']
    Sub-Category  :  ['Bookcases', 'Chairs', 'Labels', 'Tables', 'Storage', 'Furnishings', 'Art', 'Phones', 'Binders', 'Appliances', 'Paper', 'Accessories', 'Envelopes', 'Fasteners', 'Supplies', 'Machines', 'Copiers']
    Quantity  :  [2, 3, 5, 7, 4, 6, 9, 1, 8, 14, 11, 13, 10, 12]
    Discount  :  [0.0, 0.45, 0.2, 0.8, 0.3, 0.5, 0.7, 0.6, 0.32, 0.1, 0.4, 0.15]
    

DROP THE COUNTRY COLUMN BECAUSE IT HAS ONLY ONE VALUES


```python
df.drop(columns ='Country', inplace= True)
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Ship Mode</th>
      <th>Segment</th>
      <th>City</th>
      <th>State</th>
      <th>Postal Code</th>
      <th>Region</th>
      <th>Category</th>
      <th>Sub-Category</th>
      <th>Sales</th>
      <th>Quantity</th>
      <th>Discount</th>
      <th>Profit</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Second Class</td>
      <td>Consumer</td>
      <td>Henderson</td>
      <td>Kentucky</td>
      <td>42420</td>
      <td>South</td>
      <td>Furniture</td>
      <td>Bookcases</td>
      <td>261.9600</td>
      <td>2</td>
      <td>0.00</td>
      <td>41.9136</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Second Class</td>
      <td>Consumer</td>
      <td>Henderson</td>
      <td>Kentucky</td>
      <td>42420</td>
      <td>South</td>
      <td>Furniture</td>
      <td>Chairs</td>
      <td>731.9400</td>
      <td>3</td>
      <td>0.00</td>
      <td>219.5820</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Second Class</td>
      <td>Corporate</td>
      <td>Los Angeles</td>
      <td>California</td>
      <td>90036</td>
      <td>West</td>
      <td>Office Supplies</td>
      <td>Labels</td>
      <td>14.6200</td>
      <td>2</td>
      <td>0.00</td>
      <td>6.8714</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Standard Class</td>
      <td>Consumer</td>
      <td>Fort Lauderdale</td>
      <td>Florida</td>
      <td>33311</td>
      <td>South</td>
      <td>Furniture</td>
      <td>Tables</td>
      <td>957.5775</td>
      <td>5</td>
      <td>0.45</td>
      <td>-383.0310</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Standard Class</td>
      <td>Consumer</td>
      <td>Fort Lauderdale</td>
      <td>Florida</td>
      <td>33311</td>
      <td>South</td>
      <td>Office Supplies</td>
      <td>Storage</td>
      <td>22.3680</td>
      <td>2</td>
      <td>0.20</td>
      <td>2.5164</td>
    </tr>
  </tbody>
</table>
</div>



# Exploratory data analysis 
Now, let's visualise the count plot and Bar Plots for Sales and Profit for the columns: Ship Mode, Segment, Region, and Category.


```python
f, ax = plt.subplots(1, 3, figsize=(20,4))
sns.countplot(df['Ship Mode'], color = 'steelblue', order = df['Ship Mode'].value_counts().index, ax=ax[0])
ax[0].title.set_text("Orders Count of ship mode")
ax[0].set_xlabel("Ship Mode")
ax[0].set_ylabel("Orders")

ship_sale_profit = df.groupby('Ship Mode')[['Sales', 'Profit']].sum()
ship_sale_profit.sort_values(['Sales'], axis = 0, ascending = False, inplace = True) 
ship_sale_profit.plot(y='Sales', kind = "bar", color = 'steelblue', ax=ax[1])

ax[1].title.set_text('Sales in each Ship Mode')
ax[1].set_xlabel('Ship Mode')
ax[1].set_ylabel('Sales')
ax[1].get_legend().remove()

ship_sale_profit.sort_values(['Profit'], axis = 0, ascending = False, inplace = False) 
ship_sale_profit.plot(y='Profit', kind = "bar", color = 'steelblue', ax=ax[2])

ax[2].title.set_text('Profit in each Ship Mode')
ax[2].set_xlabel('Ship Mode')
ax[2].set_ylabel('Profit')
ax[2].get_legend().remove()

f.autofmt_xdate(rotation=0, ha='center')
plt.show()



```


    
![png](output_18_0.png)
    


We observe that Standard Class is the most popular shipping mode and Same Day is the least popular. Because Standard Class has the most shipments and it is a cheap shipping mode, it makes sense for it to be the most profitable


```python
 f, ax = plt.subplots(1, 3, figsize=(20,4))

sns.countplot(df['Segment'], color = 'limegreen', order = df['Segment'].value_counts().index, ax=ax[0])
ax[0].title.set_text("Order Count of Segment")
ax[0].set_xlabel("Segment")
ax[0].set_ylabel("Orders")


segment_sale_profit = df.groupby('Segment')[['Sales', 'Profit']].sum()

segment_sale_profit.sort_values(['Sales'], axis = 0, ascending = False, inplace = True) 
segment_sale_profit.plot(y='Sales', kind = "bar", color = 'limegreen', ax=ax[1])

ax[1].title.set_text('Sales in each Segment')
ax[1].set_xlabel('Segment')
ax[1].set_ylabel('Sales')
ax[1].get_legend().remove()


segment_sale_profit.sort_values(['Profit'], axis = 0, ascending = False, inplace = True) 
segment_sale_profit.plot(y='Profit', kind = "bar", color = 'limegreen', ax=ax[2])

ax[2].title.set_text('Profit in each Segment')
ax[2].set_xlabel('Segment')
ax[2].set_ylabel('Profit')
ax[2].get_legend().remove()

f.autofmt_xdate(rotation=0, ha='center')
plt.show()
segment_sale_profit.head()

```


    
![png](output_20_0.png)
    





<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Sales</th>
      <th>Profit</th>
    </tr>
    <tr>
      <th>Segment</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Consumer</th>
      <td>1.160833e+06</td>
      <td>134007.4413</td>
    </tr>
    <tr>
      <th>Corporate</th>
      <td>7.060701e+05</td>
      <td>91954.9798</td>
    </tr>
    <tr>
      <th>Home Office</th>
      <td>4.292927e+05</td>
      <td>60279.0015</td>
    </tr>
  </tbody>
</table>
</div>



We observe that Consumer is the major segment, while Home Office contributes the least.


```python
f, ax = plt.subplots(1, 3, figsize=(20,4))

sns.countplot(df['Region'], color = 'darkorange', order = df['Region'].value_counts().index, ax=ax[0])
ax[0].title.set_text("Order Count of Region")
ax[0].set_xlabel("Region")
ax[0].set_ylabel("Orders")


region_sale_profit = df.groupby('Region')[['Sales', 'Profit']].sum()

region_sale_profit.sort_values(['Sales'], axis = 0, ascending = False, inplace = True) 
region_sale_profit.plot(y='Sales', kind = "bar", color = 'darkorange', ax=ax[1])

ax[1].title.set_text('Sales in each Region')
ax[1].set_xlabel('Region')
ax[1].set_ylabel('Sales')
ax[1].get_legend().remove()


region_sale_profit.sort_values(['Profit'], axis = 0, ascending = False, inplace = True) 
region_sale_profit.plot(y='Profit', kind = "bar", color = 'darkorange', ax=ax[2])

ax[2].title.set_text('Profit in each Region')
ax[2].set_xlabel('Region')
ax[2].set_ylabel('Profit')
ax[2].get_legend().remove()

f.autofmt_xdate(rotation=0, ha='center')
plt.show()
region_sale_profit.head()
```


    
![png](output_22_0.png)
    





<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Sales</th>
      <th>Profit</th>
    </tr>
    <tr>
      <th>Region</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>West</th>
      <td>725255.6365</td>
      <td>108329.8079</td>
    </tr>
    <tr>
      <th>East</th>
      <td>678435.1960</td>
      <td>91506.3092</td>
    </tr>
    <tr>
      <th>South</th>
      <td>391721.9050</td>
      <td>46749.4303</td>
    </tr>
    <tr>
      <th>Central</th>
      <td>500782.8528</td>
      <td>39655.8752</td>
    </tr>
  </tbody>
</table>
</div>



We observe that West consists of most buyers while South consists of the least. Central region is the least profitable.


```python
f, ax = plt.subplots(1, 3, figsize=(20,4))

sns.countplot(df['Category'], color = 'rebeccapurple', order = df['Category'].value_counts().index, ax=ax[0])
ax[0].title.set_text("Order Count of Category")
ax[0].set_xlabel("Category")
ax[0].set_ylabel("Orders")


category_sale_profit = df.groupby('Category')[['Sales', 'Profit']].sum()

category_sale_profit.sort_values(['Sales'], axis = 0, ascending = False, inplace = True) 
category_sale_profit.plot(y='Sales', kind = "bar", color = 'rebeccapurple', ax=ax[1])

ax[1].title.set_text('Sales in each Category')
ax[1].set_xlabel('Category')
ax[1].set_ylabel('Sales')
ax[1].get_legend().remove()


category_sale_profit.sort_values(['Profit'], axis = 0, ascending = False, inplace = True)
category_sale_profit.plot(y='Profit', kind = "bar", color = 'rebeccapurple', ax=ax[2])

ax[2].title.set_text('Profit in each Category')
ax[2].set_xlabel('Category')
ax[2].set_ylabel('Profit')
ax[2].get_legend().remove()

f.autofmt_xdate(rotation=0, ha='center')
plt.show()
category_sale_profit.head()
```


    
![png](output_24_0.png)
    





<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Sales</th>
      <th>Profit</th>
    </tr>
    <tr>
      <th>Category</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Technology</th>
      <td>836154.0330</td>
      <td>145454.9481</td>
    </tr>
    <tr>
      <th>Office Supplies</th>
      <td>718735.2440</td>
      <td>122364.6608</td>
    </tr>
    <tr>
      <th>Furniture</th>
      <td>741306.3133</td>
      <td>18421.8137</td>
    </tr>
  </tbody>
</table>
</div>



We observe that the frequency of purchases in the Office Supplies category is significantly large as compared to Technology and Furniture. However, the sales amount for Technology is the highest, which makes sense because technological equipments are expensive, thus resulting in a larger sales despite a lower frequency of purchase. When we observe the Profit graph, we can see that Technology brings in the highest profit. But, the profit brought in by Furniture is very low considering that it has the second-highest sales, only a little different from Office Supplies. But, Office Supplies results in good profit.

Now, let's visualise the count plot for State.


```python
plt.figure(figsize=(20,8))
sns.countplot(df['State'], order = df['State'].value_counts().index, palette = 'plasma')

plt.title("Order Count for States")
plt.xticks(rotation=90)
plt.xlabel("State")
plt.ylabel("Count")
plt.show()
```


    
![png](output_26_0.png)
    


We observe that California has the highest buyers, almost double New York, which has the second-highest buyers. Wyoming has the least buyers.

Let's check out the sales and profit for each state with the help of a double bar graph.


```python
state_sale_profit = df.groupby('State')[['Sales','Profit']].sum()
state_sale_profit.head()
state_sale_profit.sort_values('Sales', ascending= False, inplace= True)
state_sale_profit.head()
state_sale_profit.plot(kind="bar", figsize=(25,12), color=['darkviolet','dodgerblue'])
plt.title('sales/profit in each state')
plt.xticks(rotation=90)
plt.xlabel('state')
plt.ylabel('sales/profit')
plt.show()
state_sale_profit.head()
```


    
![png](output_28_0.png)
    





<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Sales</th>
      <th>Profit</th>
    </tr>
    <tr>
      <th>State</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>California</th>
      <td>457576.2715</td>
      <td>76330.7891</td>
    </tr>
    <tr>
      <th>New York</th>
      <td>310827.1510</td>
      <td>74015.4622</td>
    </tr>
    <tr>
      <th>Texas</th>
      <td>170124.5418</td>
      <td>-25750.9833</td>
    </tr>
    <tr>
      <th>Washington</th>
      <td>138560.8100</td>
      <td>33368.2375</td>
    </tr>
    <tr>
      <th>Pennsylvania</th>
      <td>116496.3620</td>
      <td>-15565.4035</td>
    </tr>
  </tbody>
</table>
</div>



We notice that quite a few of the states undergo an overall loss. Texas, which has the third-highest sales, witnesses a loss. Pennsylvania (fifth-highest sales) also witnesses a loss. Other states that witness a loss are; Florida, Illinois, Ohio, North Carolina, Arizona, Colorado, Tennessee.

California has the highest profit and a close second is New York.

Out of the top 10 states with the highest sales, 5 undergo an overall loss.

Let's observe the count plot for Sub-Categories.


```python
plt.figure(figsize=(20,8))
sns.countplot(df['Sub-Category'], order=df['Sub-Category'].value_counts().index, palette= 'plasma')
plt.title('Order-Count by Sub-category')
plt.xticks(rotation=90)
plt.xlabel('Sub-Category')
plt.ylabel('orders')
plt.show()
```


    
![png](output_30_0.png)
    



```python
subcategory_sale_profit = df.groupby('Sub-Category')[['Sales','Profit']].sum()
subcategory_sale_profit.sort_values('Sales', ascending=False, inplace=True)
subcategory_sale_profit.plot(kind="bar",color=["rebeccapurple","mediumpurple"],figsize=(20,8))
plt.title('Sales/Profit in each Sub-Category')
plt.xlabel('Category')
plt.ylabel('Sales/Profit')
plt.show()
 
```


    
![png](output_31_0.png)
    



```python
cat_sub_cat = df.groupby(['Category','Sub-Category'])[['Sales','Profit']].sum().reset_index()
cat_sub_cat
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Category</th>
      <th>Sub-Category</th>
      <th>Sales</th>
      <th>Profit</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Furniture</td>
      <td>Bookcases</td>
      <td>114879.9963</td>
      <td>-3472.5560</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Furniture</td>
      <td>Chairs</td>
      <td>327777.7610</td>
      <td>26567.1278</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Furniture</td>
      <td>Furnishings</td>
      <td>91683.0240</td>
      <td>13052.7230</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Furniture</td>
      <td>Tables</td>
      <td>206965.5320</td>
      <td>-17725.4811</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Office Supplies</td>
      <td>Appliances</td>
      <td>107532.1610</td>
      <td>18138.0054</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Office Supplies</td>
      <td>Art</td>
      <td>27107.0320</td>
      <td>6524.6118</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Office Supplies</td>
      <td>Binders</td>
      <td>203409.1690</td>
      <td>30228.0003</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Office Supplies</td>
      <td>Envelopes</td>
      <td>16476.4020</td>
      <td>6964.1767</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Office Supplies</td>
      <td>Fasteners</td>
      <td>3024.2800</td>
      <td>949.5182</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Office Supplies</td>
      <td>Labels</td>
      <td>12444.9120</td>
      <td>5526.3820</td>
    </tr>
    <tr>
      <th>10</th>
      <td>Office Supplies</td>
      <td>Paper</td>
      <td>78224.1420</td>
      <td>33944.2395</td>
    </tr>
    <tr>
      <th>11</th>
      <td>Office Supplies</td>
      <td>Storage</td>
      <td>223843.6080</td>
      <td>21278.8264</td>
    </tr>
    <tr>
      <th>12</th>
      <td>Office Supplies</td>
      <td>Supplies</td>
      <td>46673.5380</td>
      <td>-1189.0995</td>
    </tr>
    <tr>
      <th>13</th>
      <td>Technology</td>
      <td>Accessories</td>
      <td>167380.3180</td>
      <td>41936.6357</td>
    </tr>
    <tr>
      <th>14</th>
      <td>Technology</td>
      <td>Copiers</td>
      <td>149528.0300</td>
      <td>55617.8249</td>
    </tr>
    <tr>
      <th>15</th>
      <td>Technology</td>
      <td>Machines</td>
      <td>189238.6310</td>
      <td>3384.7569</td>
    </tr>
    <tr>
      <th>16</th>
      <td>Technology</td>
      <td>Phones</td>
      <td>330007.0540</td>
      <td>44515.7306</td>
    </tr>
  </tbody>
</table>
</div>



We can see that while the sales for tables is the fourth-highest, it still undergoes the highest overall loss. Bookcases also witness a loss. Supplies witness the least loss. The profit incurred for machines is low.

Let's now observe the sales and profit of each sub-category separated by segment.


```python
sub_seg =df.groupby(['Sub-Category', 'Segment'])[['Quantity','Sales','Profit']].sum().reset_index()
sub_seg
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Sub-Category</th>
      <th>Segment</th>
      <th>Quantity</th>
      <th>Sales</th>
      <th>Profit</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Accessories</td>
      <td>Consumer</td>
      <td>1578</td>
      <td>87105.2380</td>
      <td>20735.9225</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Accessories</td>
      <td>Corporate</td>
      <td>881</td>
      <td>48190.5640</td>
      <td>12707.4805</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Accessories</td>
      <td>Home Office</td>
      <td>517</td>
      <td>32084.5160</td>
      <td>8493.2327</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Appliances</td>
      <td>Consumer</td>
      <td>908</td>
      <td>52819.5810</td>
      <td>6981.9282</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Appliances</td>
      <td>Corporate</td>
      <td>569</td>
      <td>36588.6830</td>
      <td>7429.8952</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Appliances</td>
      <td>Home Office</td>
      <td>252</td>
      <td>18123.8970</td>
      <td>3726.1820</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Art</td>
      <td>Consumer</td>
      <td>1625</td>
      <td>14251.9300</td>
      <td>3454.3011</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Art</td>
      <td>Corporate</td>
      <td>846</td>
      <td>8578.6880</td>
      <td>2001.4725</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Art</td>
      <td>Home Office</td>
      <td>525</td>
      <td>4276.4140</td>
      <td>1068.8382</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Binders</td>
      <td>Consumer</td>
      <td>3015</td>
      <td>118161.0090</td>
      <td>17995.5972</td>
    </tr>
    <tr>
      <th>10</th>
      <td>Binders</td>
      <td>Corporate</td>
      <td>1845</td>
      <td>51556.7490</td>
      <td>6383.5571</td>
    </tr>
    <tr>
      <th>11</th>
      <td>Binders</td>
      <td>Home Office</td>
      <td>1111</td>
      <td>33691.4110</td>
      <td>5848.8460</td>
    </tr>
    <tr>
      <th>12</th>
      <td>Bookcases</td>
      <td>Consumer</td>
      <td>496</td>
      <td>68632.7290</td>
      <td>-4435.6382</td>
    </tr>
    <tr>
      <th>13</th>
      <td>Bookcases</td>
      <td>Corporate</td>
      <td>271</td>
      <td>34005.9243</td>
      <td>638.4502</td>
    </tr>
    <tr>
      <th>14</th>
      <td>Bookcases</td>
      <td>Home Office</td>
      <td>101</td>
      <td>12241.3430</td>
      <td>324.6320</td>
    </tr>
    <tr>
      <th>15</th>
      <td>Chairs</td>
      <td>Consumer</td>
      <td>1231</td>
      <td>172472.7720</td>
      <td>13200.2346</td>
    </tr>
    <tr>
      <th>16</th>
      <td>Chairs</td>
      <td>Corporate</td>
      <td>719</td>
      <td>99140.8780</td>
      <td>8344.6565</td>
    </tr>
    <tr>
      <th>17</th>
      <td>Chairs</td>
      <td>Home Office</td>
      <td>401</td>
      <td>56164.1110</td>
      <td>5022.2367</td>
    </tr>
    <tr>
      <th>18</th>
      <td>Copiers</td>
      <td>Consumer</td>
      <td>117</td>
      <td>69819.0700</td>
      <td>24083.7106</td>
    </tr>
    <tr>
      <th>19</th>
      <td>Copiers</td>
      <td>Corporate</td>
      <td>70</td>
      <td>46829.3860</td>
      <td>18990.2789</td>
    </tr>
    <tr>
      <th>20</th>
      <td>Copiers</td>
      <td>Home Office</td>
      <td>47</td>
      <td>32879.5740</td>
      <td>12543.8354</td>
    </tr>
    <tr>
      <th>21</th>
      <td>Envelopes</td>
      <td>Consumer</td>
      <td>442</td>
      <td>7771.1460</td>
      <td>3264.4126</td>
    </tr>
    <tr>
      <th>22</th>
      <td>Envelopes</td>
      <td>Corporate</td>
      <td>323</td>
      <td>5942.6700</td>
      <td>2571.2290</td>
    </tr>
    <tr>
      <th>23</th>
      <td>Envelopes</td>
      <td>Home Office</td>
      <td>141</td>
      <td>2762.5860</td>
      <td>1128.5351</td>
    </tr>
    <tr>
      <th>24</th>
      <td>Fasteners</td>
      <td>Consumer</td>
      <td>473</td>
      <td>1680.9420</td>
      <td>576.8008</td>
    </tr>
    <tr>
      <th>25</th>
      <td>Fasteners</td>
      <td>Corporate</td>
      <td>273</td>
      <td>783.2900</td>
      <td>251.9030</td>
    </tr>
    <tr>
      <th>26</th>
      <td>Fasteners</td>
      <td>Home Office</td>
      <td>168</td>
      <td>560.0480</td>
      <td>120.8144</td>
    </tr>
    <tr>
      <th>27</th>
      <td>Furnishings</td>
      <td>Consumer</td>
      <td>1834</td>
      <td>49620.0460</td>
      <td>7919.4227</td>
    </tr>
    <tr>
      <th>28</th>
      <td>Furnishings</td>
      <td>Corporate</td>
      <td>1086</td>
      <td>25001.2660</td>
      <td>3508.2077</td>
    </tr>
    <tr>
      <th>29</th>
      <td>Furnishings</td>
      <td>Home Office</td>
      <td>640</td>
      <td>17061.7120</td>
      <td>1625.0926</td>
    </tr>
    <tr>
      <th>30</th>
      <td>Labels</td>
      <td>Consumer</td>
      <td>715</td>
      <td>6709.2620</td>
      <td>3075.9884</td>
    </tr>
    <tr>
      <th>31</th>
      <td>Labels</td>
      <td>Corporate</td>
      <td>398</td>
      <td>4101.6460</td>
      <td>1760.8273</td>
    </tr>
    <tr>
      <th>32</th>
      <td>Labels</td>
      <td>Home Office</td>
      <td>283</td>
      <td>1634.0040</td>
      <td>689.5663</td>
    </tr>
    <tr>
      <th>33</th>
      <td>Machines</td>
      <td>Consumer</td>
      <td>217</td>
      <td>79542.8250</td>
      <td>2141.0618</td>
    </tr>
    <tr>
      <th>34</th>
      <td>Machines</td>
      <td>Corporate</td>
      <td>141</td>
      <td>60276.7550</td>
      <td>703.0190</td>
    </tr>
    <tr>
      <th>35</th>
      <td>Machines</td>
      <td>Home Office</td>
      <td>82</td>
      <td>49419.0510</td>
      <td>540.6761</td>
    </tr>
    <tr>
      <th>36</th>
      <td>Paper</td>
      <td>Consumer</td>
      <td>2581</td>
      <td>36145.7680</td>
      <td>15457.9730</td>
    </tr>
    <tr>
      <th>37</th>
      <td>Paper</td>
      <td>Corporate</td>
      <td>1545</td>
      <td>23822.2180</td>
      <td>10334.3308</td>
    </tr>
    <tr>
      <th>38</th>
      <td>Paper</td>
      <td>Home Office</td>
      <td>1018</td>
      <td>18256.1560</td>
      <td>8151.9357</td>
    </tr>
    <tr>
      <th>39</th>
      <td>Phones</td>
      <td>Consumer</td>
      <td>1685</td>
      <td>169932.7640</td>
      <td>23837.1147</td>
    </tr>
    <tr>
      <th>40</th>
      <td>Phones</td>
      <td>Corporate</td>
      <td>1003</td>
      <td>91153.4140</td>
      <td>11766.2196</td>
    </tr>
    <tr>
      <th>41</th>
      <td>Phones</td>
      <td>Home Office</td>
      <td>601</td>
      <td>68920.8760</td>
      <td>8912.3963</td>
    </tr>
    <tr>
      <th>42</th>
      <td>Storage</td>
      <td>Consumer</td>
      <td>1619</td>
      <td>100492.4020</td>
      <td>7104.2004</td>
    </tr>
    <tr>
      <th>43</th>
      <td>Storage</td>
      <td>Corporate</td>
      <td>1000</td>
      <td>79790.9980</td>
      <td>9131.0247</td>
    </tr>
    <tr>
      <th>44</th>
      <td>Storage</td>
      <td>Home Office</td>
      <td>539</td>
      <td>43560.2080</td>
      <td>5043.6013</td>
    </tr>
    <tr>
      <th>45</th>
      <td>Supplies</td>
      <td>Consumer</td>
      <td>359</td>
      <td>25741.4960</td>
      <td>-1657.5513</td>
    </tr>
    <tr>
      <th>46</th>
      <td>Supplies</td>
      <td>Corporate</td>
      <td>202</td>
      <td>19435.2840</td>
      <td>338.9264</td>
    </tr>
    <tr>
      <th>47</th>
      <td>Supplies</td>
      <td>Home Office</td>
      <td>86</td>
      <td>1496.7580</td>
      <td>129.5254</td>
    </tr>
    <tr>
      <th>48</th>
      <td>Tables</td>
      <td>Consumer</td>
      <td>602</td>
      <td>99933.7950</td>
      <td>-9728.0378</td>
    </tr>
    <tr>
      <th>49</th>
      <td>Tables</td>
      <td>Corporate</td>
      <td>419</td>
      <td>70871.7175</td>
      <td>-4906.4986</td>
    </tr>
    <tr>
      <th>50</th>
      <td>Tables</td>
      <td>Home Office</td>
      <td>220</td>
      <td>36160.0195</td>
      <td>-3090.9447</td>
    </tr>
  </tbody>
</table>
</div>




```python
sns.catplot('Sub-Category', y='Sales', hue = 'Segment', data = sub_seg, kind='bar',palette='tab20c',aspect=2,height=8)
plt.title('Sub-Category Sales Segment-wise')
sns.catplot('Sub-Category', y='Profit', hue = 'Segment',data = sub_seg, kind='bar',palette='tab20c',aspect=2,height=8)
plt.title('Sub-Category Profit Segment-wise')
plt.show()
```


    
![png](output_35_0.png)
    



    
![png](output_35_1.png)
    


The first plot represents the Sales and the second plot represents Profit. We can clearly see that tables undergo a loss in each segment. Bookcases and supplies undergo a loss in the Consumer segment.

Let's plot a scatter plot for Discount vs. Profit.


```python
plt.scatter(df['Discount'], df['Profit'])
plt.title('Discount vs. Profit')
plt.xlabel('Discount')
plt.ylabel('Profit')
plt.show()
```


    
![png](output_37_0.png)
    


We can observe that more the dicsount, lesser the profit.


```python
np.mean(df['Profit'])
```




    28.69012955798336



The average profit of the firm is 28.69, which is low. But,atleast the firm is not operating at a loss.

# Inferences

 1) In Shipping Modes, the most profitable and the most preferred shipping mode is the Standard Class. 
 2) The Consumer Segment is the most profitable and has the most number of buyers.  
 3) The Western region has the most sales and profit. However, the Central region has the least profit, and the Southern region has the least sales.
 4) Office Supplies has the highest frequency of purchases. Technology has the most sales and is the most profitable. Furniture has the least profit although it has the second-highest sales.
 5) Within Furniture, Tables in all segments undergoes heavy losses, and Tables also accounts for the highest loss amongst any other product. Bookcases in the Consumer segment witnesses losses.
 6) In Office Supplies, Supplies undergoes a loss in the Consumer Segment.
 7) In Office Supplies, Appliances has more sales in the Consumer segment than in the other segments. But the profit from Corporate segment is higher than that from Consumer segment.
 8) In technology, although Machines have a pretty decent sales, the resultant profit is low. However, copiers and accessories compensate for that.
 9) Out of the top 10 states with the highest sales, 5 undergo an overall loss. 
 10) Texas, which has the third-highest sales, witnesses the highest loss.
 11) The profit for both California and New York is more or less the same. But California has the highest sales, and New York the second highest. Therefore, we can say that for the same amount of sales, New York is more profitable.
 12) A general observation is that more the sales, more the profit. 
 13) More the discount, lesser the profit. 
 14) The firm is operating at a low average profit of 28.69. But atleast it is not operating at a loss.

# THANK YOU


```python

```
